print(f'The final character is "{chr(83)}". Congratulations!')
